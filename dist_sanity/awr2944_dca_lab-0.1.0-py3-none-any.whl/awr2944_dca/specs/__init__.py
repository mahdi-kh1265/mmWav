"""Specs package."""
